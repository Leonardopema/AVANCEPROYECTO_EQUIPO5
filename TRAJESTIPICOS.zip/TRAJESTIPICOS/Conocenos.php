<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TRAJES TIPICOS</title>
    <link rel="stylesheet" href="css/estilo.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<style>
.body{
    background-color: #F3E6E6;
}
.container-fluiid {
            text-align: center;
        }

        .p {
            text-align: righ;
            padding: 12px;
            margin-top: 100px;
    text-align: center;
    margin-left: 50px;

    
        }
    </style>
</head>

</style>
</head>

<body class="body">
<header class="header">
  <div class="child-header">
    <div class="box-logo">
    <a class="navbar-brand"><img src="img/logo.png" width="130px"></a>
    </div>
    
    <nav class="box-menu-navegacion" id="menu-navegacion">
      <ul class="menu-navegacion">
        <li class="item-menu">
          <a href="index.php" class="item-menu-link">Inicio</a>
        </li>
        <li class="item-menu">
          <a href="Conocenos.php" class="item-menu-link">Conocenos</a>
        </li>
        
        <li class="item-menu item-menu-sub-menu">
          <a href="catalogo.php" class="item-menu-link">Catalogo</a>
          <i class="fas fa-angle-down angle-view-sub-menu"></i>
          
          <ul class="sub-menu" id="sub-menu">
            <li class="item-menu">
              <a href="#" class="item-menu-link"></a>
            </li>
            <li class="item-menu">
              <a href="#" class="item-menu-link"></a>
            </li>
            <li class="item-menu">
              <a href="#" class="item-menu-link"></a>
            </li>
          </ul>
        </li>
        
        <li class="item-menu item-menu-sub-menu">
          <a href="#" class="item-menu-link">Mas..</a>
          <i class="fas fa-angle-down angle-view-sub-menu"></i>
          
          <ul class="sub-menu" id="sub-menu">
            <li class="item-menu">
              <a href="Contacto.php" class="item-menu-link">Contacto</a>
            </li>
            <li class="item-menu">
              <a href="#" class="item-menu-link"></a>
            </li>
            <li class="item-menu">
              <a href="#" class="item-menu-link"></a>
            </li>
            <li class="item-menu">
              <a href="#" class="item-menu-link"></a>
            </li>
            <li class="item-menu">
              <a href="#" class="item-menu-link"></a>
            </li>
          </ul>
        </li>
      </ul>
    </nav>
    <form class="d-flex">
                <button type="button" class="btn btn-success" onclick="window.location.href = 'login.php';"><img src="img/usuario.jpg" width="50px"> Iniciar Sesión</button>
  </form>
    
 
    <button class="btn-hamburguesa" id="btn-hamburguesa">
      <span></span>
      <span></span>
      <span></span>
    </button>
 
  </div>

</header>

<script>
let btnHamburguesa = document.getElementById("btn-hamburguesa");
let menuNavegacion = document.getElementById("menu-navegacion");
btnHamburguesa.addEventListener('click', function(){
    menuNavegacion.classList.toggle("viewMenu");
});

$(".angle-view-sub-menu").click(function(){
  $(this).siblings("ul").toggle();
})
</script>
<section class="mt-5">
  <div class="container espacio-superior">
    <div class="row">
      <div class="col-md-6">
        <img src="img/1img.jpg" class="img-fluid centrar" alt="Imagen 1">
      </div>
      <div class="col-md-5 text-justify d-flex align-items-center justify-content-center">
        <div>
            <CENTER>
          <h3 style="color: #800000; text-align: center;">¡CONOCENOS!</h3>
          <p style="margin: 50px;">Chiapa de Corzo es una ciudad en el estado mexicano de Chiapas, conocida por su rica tradición cultural y festivales coloridos, especialmente el festival de los Parachicos. Los Parachicos son danzantes tradicionales vestidos con trajes coloridos y máscaras elaboradas que 
          participan en esta festividad anual para honrar a San Sebastián, el santo patrono de la ciudad.. </p>
            </CENTER>
            <footer>
    </footer>
        </div>
      </div>
    </div>
  </div>
</section>
</div>
<center>
    <div style="text-align: left;" >
      <div class="col-md-5 text-justify  ">
        
        <h4 style="color: #800000; text-align: center;">¡MISION!</h4>
          <p style="margin: 50px;">Preservamos la identidad cultural de Chiapas mediante la producción y promoción de trajes regionales auténticos y accesorios artesanales, fusionando tradición y estilo. Nos dedicamos a enriquecer las vidas de nuestros clientes al ofrecer productos de alta calidad, 
          promoviendo el comercio justo y apoyando el desarrollo socioeconómico de las comunidades locales... </p>
          
         
        </div>
    </div>
    <div style="text-align:   right center;">
      <div class="col-md-5 text-justify d-flex align-items-center justify-content-center">
  
        <center>
    <h4 style="color: #800000; text-align: ;">¡VISION!</h4>
          <p style="margin: 50px;">Nos esforzamos por ser la principal fuente mundial de trajes regionales auténticos de Chiapas y accesorios artesanales, transmitiendo la riqueza cultural y la tradición a cada rincón del planeta. Aspiramos a ser reconocidos por nuestra excelencia en calidad, diseño y compromiso con 
          las comunidades locales, creando un impacto positivo y duradero en el patrimonio cultural de Chiapas.". </p> 
    </center>
    </div>
   
 
    </center>

<CENTER><p>&copy; <?php echo date("Y"); ?> .  Estamos ubicados en el municipio de Chiapa de corzo.Tuxtla Gutierrez Chiapas.</p></CENTER>


<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
</html>
